# AI Knowledge Hub 交付包

本目录包含：

- `ARCHITECTURE.md`：完整产品、技术、数据、AI、同步、接口与开发阶段设计。
- `prototype/index.html`：可交互的移动端高保真原型，无需安装依赖，浏览器直接打开。
- FigJam 架构图：在聊天回复中的 Figma 链接打开。

## 本地预览原型

直接双击 `prototype/index.html`，或运行：

```bash
cd prototype
python3 -m http.server 8080
```

浏览器访问 `http://localhost:8080`。
