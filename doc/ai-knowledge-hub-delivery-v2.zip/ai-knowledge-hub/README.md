# AI Knowledge Hub 设计交付

本目录包含一个“Obsidian 式知识库 + AI + 独立小工具平台”的产品与工程设计。

## 文件

- `ARCHITECTURE.md`：总体产品、页面、数据、AI、多端和模块架构。
- `docs/TOOL_PLATFORM.md`：大量小工具的插件平台、Platform SDK、注册、隔离、版本、冻结与 CI 规则。
- `docs/MODULE_BOOKKEEPING.md`：记账和每月流水模块完整设计。
- `docs/MODULE_TEMPLATE.md`：以后开发任何新工具时复制使用的标准模板。
- `prototype/index.html`：可直接在浏览器打开的交互原型，已加入记账月度流水页面。

## 推荐阅读顺序

1. `ARCHITECTURE.md`
2. `docs/TOOL_PLATFORM.md`
3. `docs/MODULE_BOOKKEEPING.md`
4. `docs/MODULE_TEMPLATE.md`

## 核心开发纪律

每个模块依次通过：立项 → 契约 → 合约测试 → 开发 → 验收 → 冻结。  
冻结后其他模块只能使用它的 `public.ts`、领域事件和公共动作，不允许引用内部文件或数据表。
